import{a as t}from"../chunks/entry.DZVJK6DL.js";export{t as start};
//# sourceMappingURL=start.CbgKHVqH.js.map
