import{a as t}from"../chunks/entry.Bek5ymEx.js";export{t as start};
//# sourceMappingURL=start.C-PQcN7D.js.map
