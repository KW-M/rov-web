import{a as t}from"../chunks/entry.D6YTDmuO.js";export{t as start};
//# sourceMappingURL=start.BmeFx1IZ.js.map
