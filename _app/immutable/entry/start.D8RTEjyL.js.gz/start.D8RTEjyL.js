import{a as t}from"../chunks/entry.BcUfJaSy.js";export{t as start};
//# sourceMappingURL=start.D8RTEjyL.js.map
