import{a as t}from"../chunks/entry.CSjlzuQx.js";export{t as start};
//# sourceMappingURL=start.h3ZqfkXj.js.map
