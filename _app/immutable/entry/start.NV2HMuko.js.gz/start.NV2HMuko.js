import{a as t}from"../chunks/entry.BAFrnoys.js";export{t as start};
//# sourceMappingURL=start.NV2HMuko.js.map
