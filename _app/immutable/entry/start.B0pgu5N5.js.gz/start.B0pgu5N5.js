import{a as t}from"../chunks/entry.CHM6RMyY.js";export{t as start};
//# sourceMappingURL=start.B0pgu5N5.js.map
