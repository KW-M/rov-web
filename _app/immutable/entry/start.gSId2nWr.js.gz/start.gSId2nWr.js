import{a as t}from"../chunks/entry.DtqOzKM1.js";export{t as start};
//# sourceMappingURL=start.gSId2nWr.js.map
