import{a as t}from"../chunks/entry.DBaSshOF.js";export{t as start};
//# sourceMappingURL=start.q1I5wXZb.js.map
