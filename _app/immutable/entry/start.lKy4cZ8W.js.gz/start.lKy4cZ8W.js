import{a as t}from"../chunks/entry.DyEEJo18.js";export{t as start};
//# sourceMappingURL=start.lKy4cZ8W.js.map
