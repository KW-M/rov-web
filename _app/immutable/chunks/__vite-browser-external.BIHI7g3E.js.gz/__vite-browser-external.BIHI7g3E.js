const e={};export{e as default};
//# sourceMappingURL=__vite-browser-external.BIHI7g3E.js.map
