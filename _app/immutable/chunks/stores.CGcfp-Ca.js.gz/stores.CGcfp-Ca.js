import{s as e}from"./entry.CHM6RMyY.js";const r=()=>{const s=e;return{page:{subscribe:s.page.subscribe},navigating:{subscribe:s.navigating.subscribe},updated:s.updated}},b={subscribe(s){return r().page.subscribe(s)}};export{b as p};
//# sourceMappingURL=stores.CGcfp-Ca.js.map
